import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.function.Consumer;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class IceHockey extends JFrame {
    private final CardLayout cardLayout = new CardLayout(); // CardLayout 사용해서 Panel 번갈아 사용하기
    private final JPanel mainPanel = new JPanel(cardLayout); // 사용할 Panel mainPanel에 저장
    private final StartPanel startPanel = new StartPanel(); // 시작 화면
    private final GamePanel gamePanel = new GamePanel(); // 게임 화면

    public IceHockey() {
        setTitle("Ice Hockey 2P Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        mainPanel.setPreferredSize(new Dimension(1300, 700)); // Layout에서 지정할 때 setSize는 안됨.
        mainPanel.add(startPanel, "Start"); // 시작 화면 mainPanel에 추가
        mainPanel.add(gamePanel, "Game"); // 게임 화면 mainPanel에 추가

        //게임 캐릭터 이미지 불러오기
        String[] characterImages = {
                "./images/상상부기.png",
                "./images/한성냥이.png",
                "./images/상찌.png",
                "./images/꼬꼬.png",
                "./images/꾸꾸.png",
                "./images/로고.png"
            };
        
        SelectPanel selectPanel = new SelectPanel(characterImages); // 캐릭터 이미지 전달하며 캐릭터 선택화면 생성
        mainPanel.add(selectPanel, "Select"); // 캐릭터 선택 화면 mainPanel에 추가
        
        // startPanel의 게임 시작 버튼이 눌리면 다음 코드 실행
        startPanel.setStartListener(() -> {
            cardLayout.show(mainPanel, "Select"); // 캐릭터 선택 화면 출력

            // Player A 선택
            selectPanel.setOnCharacterSelected(aIndex -> {
                selectPanel.disableCharacter(aIndex); // Player A가 선택한 캐릭터 비활성화
                JOptionPane.showMessageDialog(this, "Player B, choose your character.");
                
                // Player B 선택
                selectPanel.setOnCharacterSelected(bIndex -> {
                    cardLayout.show(mainPanel, "Game"); // 게임 화면 출력
                    gamePanel.setPlayerImages(characterImages[aIndex], characterImages[bIndex]); // 캐릭터 이미지 설정
                    JOptionPane.showMessageDialog(this, "Player A: WASD\nPlayer B: Arrow"); // 조작법 설명 메시지 출력
                    gamePanel.requestFocusInWindow(); // GamePanel에 포커스 요청
                });
            });
            // Player A에게 캐릭터 선택하라는 메시지 출력 (비동기적 실행)
            JOptionPane.showMessageDialog(this, "Player A, choose your character.");
        });

        // 게임이 종료되면 승리 메시지 출력 후 종료 또는 다시하기 메시지 출력
        gamePanel.setEndListener(winner -> {
            JOptionPane.showMessageDialog(this, winner + " wins!");
            int choice = JOptionPane.showConfirmDialog(this, "Do you want to restart?", "Game Over", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                gamePanel.resetGame();
                selectPanel.resetCharacters();
                cardLayout.show(mainPanel, "Start");
            } else {
                System.exit(0);
            }
        });

        add(mainPanel); // 전반적인 세팅 후 mainPanel을 contentPane에 추가
        pack(); // 프레임 크기 자동 조정(min 1300, 700)
        setVisible(true);
    }

    public static void main(String[] args) {
        new IceHockey();
    }
    
    // 효과음 구현 클래스
    public static class SoundEffect{
    	private final String filePath;
    	
    	public SoundEffect(String filePath) {
    		this.filePath = filePath; // 생성자. 파일 경로 전달받기
    	}
    	
    	// Thread 이용해서 효과음 출력
    	public void play() {
    		new Thread(() -> {
    			try(AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(filePath))){
    				Clip clip = AudioSystem.getClip();
    				clip.open(audioStream);
    				clip.start();
    			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
    				e.printStackTrace();
    			}
    		}).start();
    	}
    }

    // 시작 화면
    private static class StartPanel extends JPanel {
        private final JButton startButton = new JButton("Start Game");
        private Runnable startListener;
        private final Image backgroundImage;

        public StartPanel() {
        	// 배경 이미지 로드
        	backgroundImage = new ImageIcon("./images/StartPanelBG.png").getImage();
        	// 시작 버튼 추가
            setPreferredSize(new Dimension(1300, 700));
            setLayout(null);
            startButton.setSize(120, 40);
    		startButton.setLocation(295, 390);
            add(startButton);

            // 버튼에 클릭 이벤트 리스너 추가. 버튼 클릭 시 ActionListener 실행
            startButton.addActionListener(e -> {
                if (startListener != null) {
                    startListener.run();
                }
            });
        }

        public void setStartListener(Runnable listener) {
            this.startListener = listener;
        }
        
        protected void paintComponent(Graphics g) {
        	super.paintComponent(g);
        	g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
        }
    }

    // 게임 화면. ActionListener(게임 루프를 처리하는 타이머 이벤트 처리), KeyListener(키보드 입력 이벤트 처리)
    private static class GamePanel extends JPanel implements ActionListener, KeyListener {
        private final int width = 1300, height = 700;
        private final Timer timer; // 초당 60회 actionPerformed 호출(60FPS)
        private int aScore = 0, bScore = 0; // 각 플레이어의 점수
        // 플레이어의 시작 위치를 지정하며 객체 생성
        private final Player playerA = new Player(width / 3 - 25, height / 2 - 25);
        private final Player playerB = new Player(width / 3 * 2 - 25, height / 2 - 25);
        private final Puck puck = new Puck(); // 공 객체 생성
        private Consumer<String> endListener; // 게임 종료 이벤트를 처리하는 리스너(승리 플레이어 메시지)
        // 효과음 파일 경로 전달하며 객체 생성
        private final SoundEffect hitSound = new SoundEffect("./sounds/collision.wav");
        private boolean isAColliding = false; // 총돌 시 사운드 출력 관련 변수
        private boolean isBColliding = false; // 공과 플레이어가 붙는 경우 사운드 연속 출력 방지

        public GamePanel() {
            setPreferredSize(new Dimension(width, height));
            setBackground(Color.WHITE);
            setFocusable(true); // 키보드 입력을 받을 수 있도록 포커스 설정
            addKeyListener(this); // 키 입력 이벤트를 처리할 리스너 추가

            timer = new Timer(1000 / 60, this); // 60FPS
            timer.start();
        }

        // 게임 종료 리스너(리스너는 승리 플레이어 객체)
        public void setEndListener(Consumer<String> listener) {
            this.endListener = listener;
        }

        // 플레이어 이미지 설정
        public void setPlayerImages(String playerAImagePath, String playerBImagePath) {
            playerA.setImage(playerAImagePath);
            playerB.setImage(playerBImagePath);
        }
        
        // 각 객체의 위치 업데이트, repaint 요청
        public void actionPerformed(ActionEvent e) {
            puck.update();
            playerA.update();
            playerB.update();
            handleCollisions();
            repaint();
        }

        // 화면 그리기
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            drawField(g);
            drawScore(g);
            puck.draw(g);
            playerA.draw(g);
            playerB.draw(g);
        }

        // 키보드 입력 처리
        public void keyPressed(KeyEvent e) { // 플레이어 이동 관리
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W -> playerA.setDy(-12);
                case KeyEvent.VK_S -> playerA.setDy(12);
                case KeyEvent.VK_A -> playerA.setDx(-12);
                case KeyEvent.VK_D -> playerA.setDx(12);
                case KeyEvent.VK_UP -> playerB.setDy(-12);
                case KeyEvent.VK_DOWN -> playerB.setDy(12);
                case KeyEvent.VK_LEFT -> playerB.setDx(-12);
                case KeyEvent.VK_RIGHT -> playerB.setDx(12);
            }
        }

        public void keyReleased(KeyEvent e) { // 플레이어 정지 관리
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W, KeyEvent.VK_S -> playerA.setDy(0);
                case KeyEvent.VK_A, KeyEvent.VK_D -> playerA.setDx(0);
                case KeyEvent.VK_UP, KeyEvent.VK_DOWN -> playerB.setDy(0);
                case KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT -> playerB.setDx(0);
            }
        }

        public void keyTyped(KeyEvent e) {}

        // 객체 충돌 처리 메소드
        private void handleCollisions() {
        	// 객체의 현재 위치와 그 범위 추출
            Rectangle playerABounds = playerA.getBounds();
            Rectangle playerBBounds = playerB.getBounds();
            Rectangle puckBounds = puck.getBounds();

            // 공과 플레이어 충돌 처리
            if (playerABounds.intersects(puckBounds)) {
                puck.bounce(playerA.getDx() * 2, playerA.getDy() * 2); // 공 반사 처리
                playerA.applyReduction(0.8, 8); // 플레이어 A 순간 감속
                if(isAColliding == false) { // 사운드 처리
                	hitSound.play();
                	isAColliding = true;
                }
            }
            else isAColliding = false;
            if (playerBBounds.intersects(puckBounds)) {
                puck.bounce(playerB.getDx() * 2, playerB.getDy() * 2); // 공 반사 처리
                playerB.applyReduction(0.8, 8); // 플레이어 B 순간 감속
                if(isBColliding == false) { // 사운드 처리
                	hitSound.play();
                	isBColliding = true;
                }
            }
            else isBColliding = false;

            // 플레이어 간 충돌 처리
            if (playerABounds.intersects(playerBBounds)) {
                handlePlayerCollision(playerA, playerB);
            }

            // 골 체크
            if (puckBounds.intersects(new Rectangle(50, height / 2 - 40, 10, 80))) {
                bScore++;
                checkWinCondition();
                resetPositions();
            } else if (puckBounds.intersects(new Rectangle(width - 60, height / 2 - 40, 10, 80))) {
                aScore++;
                checkWinCondition();
                resetPositions();
            }
        }
        
        // 플레이어 간 충돌 처리 메소드
        private void handlePlayerCollision(Player playerA, Player playerB) {
            double dx = playerB.getX() - playerA.getX();
            double dy = playerB.getY() - playerA.getY();
            double distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < 50) { // 충돌 조건
                // 충돌 방향 단위 벡터
                double nx = dx / distance;
                double ny = dy / distance;

                // 위치 겹침 해소 (즉시 반발)
                double overlap = 50 - distance;
                playerA.setPosition(playerA.getX() - (int) (nx * overlap / 2),
                                    playerA.getY() - (int) (ny * overlap / 2));
                playerB.setPosition(playerB.getX() + (int) (nx * overlap / 2),
                                    playerB.getY() + (int) (ny * overlap / 2));
            }
        }

        // 승리 처리 메소드
        private void checkWinCondition() {
            if (aScore >= 3) {
                if (endListener != null) endListener.accept("Player A");
            } else if (bScore >= 3) {
                if (endListener != null) endListener.accept("Player B");
            }
        }

        // 배경 필드 그리는 메소드
        private void drawField(Graphics g) {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, width, height);

            g.setColor(Color.RED);
            g.fillRect(width / 2 - 1, 0, 2, height);

            g.setColor(Color.RED);
            g.drawOval(width / 2 - 75, height / 2 - 75, 150, 150);
            g.fillOval(width / 2 - 5, height / 2 - 5, 10, 10);

            g.setColor(Color.GRAY);
            g.drawRect(50, height / 2 - 40, 10, 80);
            g.drawRect(width - 60, height / 2 - 40, 10, 80);
        }

        // 점수판 그리는 메소드
        private void drawScore(Graphics g) {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("A Score: " + aScore, 50, 50);
            g.drawString("B Score: " + bScore, width - 200, 50);
        }

        // 득점 시 객체 위치 초기화
        private void resetPositions() {
            playerA.setPosition(width / 3 - 25, height / 2 - 25);
            playerB.setPosition(width / 3 * 2 - 25, height / 2 - 25);
            playerA.setDx(0);
            playerA.setDy(0);
            playerB.setDx(0);
            playerB.setDy(0);
            puck.reset(width / 2 - 15, height / 2 - 15);
        }

        // 게임 종료 후 다시 시작 처리 메소드
        public void resetGame() {
            aScore = 0;
            bScore = 0;
            resetPositions();
        }
    }

    // 플레이어 객체
    private static class Player {
        private int x, y; // 위치
        private double dx, dy; // 속도
        private Image image; // 캐릭터 이미지
        private int speedReductionCounter = 0; // 감속 카운터(공과 충돌 시 감속 처리에 사용)

        public Player(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public void setImage(String imagePath) {
            this.image = new ImageIcon(imagePath).getImage();
        }
        
        public int getX() {
        	return x;
        }
        
        public int getY() {
        	return y;
        }

        public double getDx() {
            return dx;
        }

        public double getDy() {
            return dy;
        }

        public void setDx(double dx) {
            this.dx = dx;
        }

        public void setDy(double dy) {
            this.dy = dy;
        }

        // 감속 처리 메소드
        public void applyReduction(double factor, int duration) {
            // 기존 속도를 일시적으로 감소
            dx *= factor;
            dy *= factor;

            // 일정 시간 후 속도를 복원
            speedReductionCounter = duration;
        }

        // 플레이어 상태 최신화
        public void update() {
            x += dx;
            y += dy;

            // 경기장 경계를 넘지 않도록 제한
            x = Math.max(0, Math.min(x, 1250));
            y = Math.max(0, Math.min(y, 650));

            // 감속 카운터가 활성화되었으면 감소 중단
            if (speedReductionCounter > 0) {
                speedReductionCounter--;
                if (speedReductionCounter == 0) {
                    dx *= 1.25; // 원래 속도로 복원
                    dy *= 1.25;
                }
            }
        }

        // 플레이어 그리기
        public void draw(Graphics g) {
            if (image != null) {
                g.drawImage(image, x, y, 50, 50, null);
            } else {
                g.setColor(Color.GRAY);
                g.fillOval(x, y, 50, 50);
            }
        }

        // 플레이어 객체 범위 구하는 메소드
        public Rectangle getBounds() {
            return new Rectangle(x, y, 50, 50);
        }

        // 플레이어 위치 지정
        public void setPosition(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    // 공 객체
    private static class Puck {
        private int x, y;
        private double dx, dy;
        private final int MAX_SPEED = 20; // 공의 최고 속도
        private final double FRICTION = 0.98; // 공의 마찰 계수

        public Puck() {
            reset(635, 335);
        }

        // 공의 상태 최신화
        public void update() {
            x += dx;
            y += dy;

            // 벽 충돌 검사
            if (x <= 0 || x >= 1270) {
                dx = -dx; // x 방향 반전
                if (x <= 0) x = 0; // 벽 밖으로 벗어나지 않도록 보정
                if (x >= 1270) x = 1270;
            }

            if (y <= 0 || y >= 670) {
                dy = -dy; // y 방향 반전
                if (y <= 0) y = 0; // 벽 밖으로 벗어나지 않도록 보정
                if (y >= 670) y = 670;
            }

            // 속도 감소 (마찰 효과)
            dx *= FRICTION;
            dy *= FRICTION;

            // 너무 느려지면 멈추도록 설정
            if (Math.abs(dx) < 0.1) dx = 0;
            if (Math.abs(dy) < 0.1) dy = 0;
        }

        // 공이 튕겨나가는 속도 설정
        public void bounce(double playerDx, double playerDy) {
            dx = playerDx * 1.5;
            dy = playerDy * 1.5;

            if (Math.abs(dx) > MAX_SPEED) dx = MAX_SPEED * Math.signum(dx);
            if (Math.abs(dy) > MAX_SPEED) dy = MAX_SPEED * Math.signum(dy);
        }

        // 공 그리기
        public void draw(Graphics g) {
            g.setColor(Color.BLACK);
            g.fillOval(x, y, 30, 30);
        }

        // 공 객체 범위 구하는 메소드
        public Rectangle getBounds() {
            return new Rectangle(x, y, 30, 30);
        }

        // 공 초기 위치로 리셋
        public void reset(int x, int y) {
            this.x = x;
            this.y = y;
            this.dx = 0;
            this.dy = 0;
        }
    }
    
    // 캐릭터 선택 화면
    private static class SelectPanel extends JPanel {
        private final JButton[] characterButtons;
        private Consumer<Integer> onCharacterSelected;

        public SelectPanel(String[] characterImages) {
        	// 캐릭터 선택 버튼 생성, 배치
            characterButtons = new JButton[characterImages.length];
            setLayout(new GridLayout(1, characterImages.length));

            for (int i = 0; i < characterImages.length; i++) {
                ImageIcon icon = new ImageIcon(characterImages[i]);
                JButton button = new JButton(icon);
                characterButtons[i] = button;
                final int index = i;
                // 버튼 클릭 이벤트 추가
                button.addActionListener(e -> {
                    if (onCharacterSelected != null) onCharacterSelected.accept(index);
                });
                add(button);
            }
        }

        // 선택된 캐릭터 전달
        public void setOnCharacterSelected(Consumer<Integer> listener) {
            this.onCharacterSelected = listener;
        }

        // 선택된 캐릭터 비활성화
        public void disableCharacter(int index) {
            characterButtons[index].setEnabled(false);
        }
        
        // 게임 재시작 시 비활성화 풀기
        public void resetCharacters() {
        	for(JButton button : characterButtons) {
        		button.setEnabled(true);
        	}
        }
    }
}